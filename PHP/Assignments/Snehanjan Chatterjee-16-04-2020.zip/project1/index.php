<?php
    echo "Warning error";
    include ("external_file.php");
    echo "Rest of code";
?>