<?php
    echo "Fatal error";
    callme("myphoneno");
    echo "Rest of code";
?>